package com.wixmat.sosialapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {

    private EditText uname,pwd;
    private FirebaseAuth mauth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        uname = findViewById(R.id.login_email);
        pwd = findViewById(R.id.loign_pwd);
        progressDialog = new ProgressDialog(this);

        FirebaseApp.initializeApp(login.this);
    }

    public void login_signup(View view) {
        Intent signupIntent = new Intent(login.this, reg.class);
        startActivity(signupIntent);
    }

    public void login_with_google(View view) {
    }

    public void login(View view) {
        String password = pwd.getText().toString();
        String email = uname.getText().toString();

        if(pwd.equals("")){
            Toast.makeText(this, R.string.login_toast1, Toast.LENGTH_LONG).show();

        }else if(uname.equals("")) {
            Toast.makeText(this, R.string.login_toast, Toast.LENGTH_LONG).show();
        }else{
            progressDialog.setTitle("Login In");
            progressDialog.setMessage(R.string.login_progressbar+"");
            progressDialog.show();
            progressDialog.setCanceledOnTouchOutside(true);
            mauth = FirebaseAuth.getInstance();
            mauth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()) {
                        Toast.makeText(login.this,R.string.login_complete, Toast.LENGTH_LONG).show();
                        sendUserToMainAcitity();
                        progressDialog.dismiss();
                    }else
                        Toast.makeText(login.this, R.string.login_incomplete+task.getException().toString(), Toast.LENGTH_LONG).show();
                    progressDialog.dismiss();

                }
            });
        }

    }




    private void sendUserToMainAcitity() {
        Intent mainActitiyIntent = new Intent(login.this, MainActivity.class);
        mainActitiyIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(mainActitiyIntent);
        finish();
    }
}
