package com.wixmat.sosialapp;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;


import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

public class setup extends AppCompatActivity {

    private EditText firstNameTxt, lastNameTxt, dateTxt, uname;
    private RadioGroup radioGroupGender;
    private RadioButton malegbtn, femalegbtn;
    private ImageView imageView;


    private int gselection;
    private int date;
    private int year;
    private int month;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference userRef;
    private StorageReference UserProfileImageRef;

    private final String Tag = "DataPicker";
    private String cuserid;

    final static int Gallery_Pick = 1;

    ProgressDialog progressDialog;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        imageView = findViewById(R.id.profile_image);
        firstNameTxt = findViewById(R.id.first_name_txt);
        lastNameTxt = findViewById(R.id.last_name_txt);
        malegbtn = findViewById(R.id.malegbtn);
        femalegbtn = findViewById(R.id.femalegbtn);
        radioGroupGender = findViewById(R.id.gnder_grop);
        dateTxt = findViewById(R.id.bithday_txt);
        uname = findViewById(R.id.unametxt);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        FirebaseApp.initializeApp(setup.this);
        UserProfileImageRef = FirebaseStorage.getInstance().getReference().child("Profile Images");
        cuserid = mAuth.getCurrentUser().getUid();
        userRef = database.getInstance().getReference().child("Users").child(cuserid);
        progressDialog = new ProgressDialog(this);

    }

    public void setDate(View view) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog dialog = new DatePickerDialog(
                setup.this,
                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                mDateSetListener,
                year, month, day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(Tag, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                String date = month + "/" + day + "/" + year;
                dateTxt.setText(date);
            }
        };

    }

    public void reg(View view) {
        saveAccoutnInformation();
    }

    private void saveAccoutnInformation() {
        String fname = firstNameTxt.getText().toString();
        String lname = lastNameTxt.getText().toString();
        String bod = dateTxt.getText().toString();
        String uanme = uname.getText().toString();
        String gender = "";
        gselection = radioGroupGender.getCheckedRadioButtonId();
        if (gselection == R.id.malegbtn) {
            gender = "male";
        } else if (gselection == R.id.femalegbtn) {
            gender = "female";

        }

        if (fname.isEmpty())
            Toast.makeText(setup.this, R.string.setup_fname_error, Toast.LENGTH_LONG).show();
        if (lname.isEmpty())
            Toast.makeText(setup.this, R.string.setup_lname_error, Toast.LENGTH_LONG).show();
        if (bod.isEmpty())
            Toast.makeText(setup.this, R.string.setup_bod_error, Toast.LENGTH_LONG).show();
        if (gender.isEmpty())
            Toast.makeText(setup.this, R.string.setup_gender_error, Toast.LENGTH_LONG).show();
        if (uanme.isEmpty())
            Toast.makeText(setup.this, R.string.setup_uname_error, Toast.LENGTH_LONG).show();
        else {
            progressDialog.setTitle(R.string.setup_title);
            progressDialog.setMessage(R.string.setup_msg + "");
            progressDialog.show();
            progressDialog.setCanceledOnTouchOutside(true);
            HashMap usermap = new HashMap();
            usermap.put("uname", fname);
            usermap.put("lname", lname);
            usermap.put("uname", uanme);
            usermap.put("bod", bod);
            usermap.put("gender", gender);
            usermap.put("status", R.string.setup_status);

            userRef.updateChildren(usermap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if (task.isSuccessful()) {
                        sendToMainAcitity();
                        Log.d("hello", "error");
                        Toast.makeText(setup.this, R.string.setup_toast1, Toast.LENGTH_LONG).show();

                    } else
//                        Toast.makeText(setup.this, R.string.setup_toast2+task.getException().getMessage().toString(), Toast.LENGTH_LONG).show();

                        progressDialog.dismiss();
                }
            });

        }


    }

    private void sendToMainAcitity() {
        Intent mainActitiyIntent = new Intent(setup.this, MainActivity.class);
        mainActitiyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK
        );
        startActivity(mainActitiyIntent);
        finish();
    }

    public void setImage(View view) {
        Intent gallIntent = new Intent();
        gallIntent.setAction(Intent.ACTION_GET_CONTENT);
        gallIntent.setType("image/*");
        startActivityForResult(gallIntent, Gallery_Pick);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Gallery_Pick && resultCode == RESULT_OK && data != null) {
            Uri ImageUri = data.getData();
            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }

        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK)
            {
                progressDialog.setTitle("Profile Image");
                progressDialog.setMessage("Please wait, while we updating your profile image...");
                progressDialog.show();
                progressDialog.setCanceledOnTouchOutside(true);

                Uri resultUri = result.getUri();

                StorageReference filePath = UserProfileImageRef.child(cuserid + ".jpg");

                filePath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(setup.this, "Profile Image stored successfully to Firebase storage...", Toast.LENGTH_SHORT).show();

                            final String downloadUrl = task.getResult().getUploadSessionUri().toString();

                            userRef.child("profileimage").setValue(downloadUrl)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task)
                                        {
                                            if(task.isSuccessful())
                                            {
                                                Intent selfIntent = new Intent(setup.this, setup.class);
                                                startActivity(selfIntent);

                                                Toast.makeText(setup.this, "Profile Image stored to Firebase Database Successfully...", Toast.LENGTH_SHORT).show();
                                                progressDialog.dismiss();
                                            }
                                            else
                                            {
                                                String message = task.getException().getMessage();
                                                Toast.makeText(setup.this, "Error Occured: " + message, Toast.LENGTH_SHORT).show();
                                                progressDialog.dismiss();
                                            }
                                        }
                                    });
                        }
                    }
                });


            }
            else
            {
                Toast.makeText(this, "Error Occured: Image can not be cropped. Try Again.", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }

    }
}